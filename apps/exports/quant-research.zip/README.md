# Quant Research

Exported from MemoryTonic on 2026-06-14

## Stats
- **3** projects
- **289** entities
- **58** relationships
- **6** causal chains
- **5** bridge entities (cross-project)

## Projects
### strategic rebalancing
**Finance** / Investment Management

This document delves into the mechanics of portfolio rebalancing strategies, primarily focusing on the popular 60-40 stock-bond portfolio. It highlights that a traditional mechanical rebalancing strategy, involving regular reallocation to fixed portfolio weights (e.g., monthly or quarterly), is an a...

### 2407.21791v1
**Finance** / Quantitative Finance

This document introduces a novel, end-to-end deep learning framework for options trading, aiming to surpass traditional rule-based and model-dependent strategies. The core innovation lies in its ability to directly learn complex, non-trivial mappings from raw market data to optimal trading signals, ...

### rrppqi_@
**Economics** / Finance

This research introduces a novel quantitative model designed to predict option movements by meticulously analyzing "Residual Transactions." These transactions are defined as trades that deviate significantly from standard institutional hedging activities, offering a unique and deeper lens into insti...

## Bridge Entities (cross-project connections)

| Entity | Category | Projects | Tier |
|--------|----------|----------|------|
| Open interest | Concept | 2 | silver |
| Momentum | Concept | 2 | silver |
| Implied volatility | Concept | 2 | silver |
| Federal Reserve | Organization | 1 | bronze |
| Capital Allocation | Process | 1 | bronze |

## Files
- `graph.json` — Complete knowledge graph (agent-readable, no database needed)
- `embeddings.json` — Raw 384d BERT vectors for vector search
- `manifest.json` — Export metadata and checksums
- `projects/<name>/source.html` — Full styled source documents
- `projects/<name>/extraction.json` — Raw extraction artifacts

## For AI Agents
Load `graph.json` to reason over this collection. No database required.
Entities, relationships, causal chains, bridges, and similarity pairs are all included.
For the full source text, read the HTML files in `projects/`.